//Checkbox
dropDownBB = ( value ) => {

    let checkboxBB = document.getElementById(value);
    console.log(checkboxBB)
    checkboxBB.classList.toggle('is-active');

}
window.onload = function() {

    let input = document.getElementById('searchBB');
    let placeholder = document.getElementById('placeholder');
    
    //Listener click to close placeholder search
    document.body.addEventListener("click", function (evt) {

        let classList = placeholder.classList.length;
        if (classList === 2) {
            placeholder.classList.remove('enable-event');
        }   
        
    });

    //Listener write search
    input.addEventListener('keypress', e => {
        console.log("write");
        placeholder.classList.add('enable-event');
        if(e.repeat){
            e.preventDefault();
            return;
        }
        console.log('keypress ' + String.fromCharCode(e.which || e.keyCode))
        });

        input.addEventListener('keyup', e =>{
        console.log('keyup');
    })

}   

searchResult = () => {
    console.log("Result Search")
    location.reload();
}